import { memo } from "react";
import { AlertCircle, FileQuestion } from "lucide-react";
import { useTranslation } from "react-i18next";
import type { PreviewDetails } from "./types";
import { formatFileSize } from "./types";
import { CardHeader } from "./CardHeader";

export const FallbackCard = memo(function FallbackCard({ details }: { details: PreviewDetails }) {
  const { t } = useTranslation("chat");
  const hasError = details.status === "error" || details.status === "not_found";

  return (
    <div className="rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700/40 bg-white dark:bg-gray-900/60">
      <CardHeader
        icon={
          hasError ? (
            <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
          ) : (
            <FileQuestion className="w-3.5 h-3.5 text-gray-400 shrink-0" />
          )
        }
        label={details.title ?? details.source}
        absolutePath={details.absolutePath}
      />
      <div className="px-3 py-3 text-xs space-y-1">
        {details.error ? (
          <div className="text-red-500 dark:text-red-400">{details.error}</div>
        ) : (
          <>
            <div className="text-gray-600 dark:text-gray-400">
              {t("typeLabel", { type: details.resourceType })}
            </div>
            {details.mimeType && (
              <div className="text-gray-400 dark:text-gray-500">
                {t("mimeLabel", { mime: details.mimeType })}
              </div>
            )}
            {details.size != null && (
              <div className="text-gray-400 dark:text-gray-500">
                {t("sizeLabel", { size: formatFileSize(details.size) })}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
});
