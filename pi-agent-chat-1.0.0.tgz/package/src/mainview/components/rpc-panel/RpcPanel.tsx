import { Trash2, ArrowUpRight, ArrowDownLeft, Copy, Check, Wifi, WifiOff } from "lucide-react";
import { useCallback } from "react";
import { useTranslation } from "react-i18next";
import { useRpcDebugStore, type RpcLogEntry } from "../../stores/use-rpc-debug-store";
import { useAppStore } from "../../stores/use-app-store";
import { useClipboard } from "../chat/preview/use-clipboard";

const DIR_ICONS = {
  call: ArrowUpRight,
  event: ArrowDownLeft,
  response: ArrowUpRight,
};

const DIR_COLORS = {
  call: "text-blue-400",
  event: "text-green-400",
  response: "text-purple-400",
};

function RpcEntry({ entry }: { entry: RpcLogEntry }) {
  const { t } = useTranslation("debug");
  const { copied, copy } = useClipboard();
  const Icon = DIR_ICONS[entry.direction];
  const color = DIR_COLORS[entry.direction];
  const label = entry.method ?? entry.eventType ?? entry.direction;
  const time = new Date(entry.timestamp).toLocaleTimeString("en-US", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const fullPayload = JSON.stringify(entry.payload, null, 2);
  const truncated = JSON.stringify(entry.payload).slice(0, 200);

  const handleCopy = useCallback(() => {
    copy(fullPayload);
  }, [fullPayload, copy]);

  return (
    <div className="group px-2 py-1 border-b border-gray-200/30 dark:border-gray-800/30 hover:bg-gray-200/30 dark:hover:bg-gray-800/30">
      <div className="flex items-center gap-1 mb-0.5">
        <Icon className={`w-2.5 h-2.5 shrink-0 ${color}`} />
        <span className={color}>{label}</span>
        <span className="text-gray-400 dark:text-gray-600 ml-auto">{time}</span>
        <button
          onClick={handleCopy}
          className="p-0.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400 dark:text-gray-600 hover:text-gray-700 dark:hover:text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
          title={t("copyPayload")}
        >
          {copied ? (
            <Check className="w-2.5 h-2.5 text-green-400" />
          ) : (
            <Copy className="w-2.5 h-2.5" />
          )}
        </button>
      </div>
      <div className="text-gray-500 dark:text-gray-500 break-all leading-tight pl-3.5">
        {truncated}
      </div>
    </div>
  );
}

export function RpcPanel() {
  const { t } = useTranslation("debug");
  const entries = useRpcDebugStore((s) => s.entries);
  const clear = useRpcDebugStore((s) => s.clear);
  const connectionStatus = useAppStore((s) => s.connectionStatus);
  const isConnected = connectionStatus === "connected";

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-2.5 py-1.5 border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div className="flex items-center gap-1.5">
          {isConnected ? (
            <Wifi className="w-3 h-3 text-green-400" />
          ) : (
            <WifiOff className="w-3 h-3 text-red-400" />
          )}
          <span className="text-[11px] font-medium text-gray-700 dark:text-gray-300">
            {t("rpcEvents")}
          </span>
          <span className={`text-[9px] ${isConnected ? "text-green-400" : "text-red-400"}`}>
            {isConnected ? t("connected") : t("disconnected")}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-gray-400 dark:text-gray-600">{entries.length}</span>
          <button
            onClick={clear}
            className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-400 dark:text-gray-600 hover:text-gray-700 dark:hover:text-gray-300"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto text-[10px] font-mono">
        {entries.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400 dark:text-gray-600">
            {t("noRpcEvents")}
          </div>
        ) : (
          entries.map((entry) => <RpcEntry key={entry.id} entry={entry} />)
        )}
      </div>
    </div>
  );
}
