/**
 * File 模块 — 文件系统操作
 */
export interface FileChangedEvent {
  changedPath: string;
  type: "create" | "delete" | "rename";
}

export interface FileEvents {
  "file.changed": FileChangedEvent;
}

export interface FileMethods {
  "file.findProjectRoot": {
    params: Record<string, never>;
    result: { path: string };
  };
  "file.listDir": {
    params: { path: string };
    result: {
      entries: {
        name: string;
        path: string;
        type: "file" | "directory";
        size?: number;
        isIgnored?: boolean;
      }[];
      basePath: string;
    };
  };
  "file.createFile": {
    params: { dirPath: string; name: string };
    result: { path: string };
  };
  "file.createDir": {
    params: { dirPath: string; name: string };
    result: { path: string };
  };
  "file.rename": {
    params: { oldPath: string; newName: string };
    result: { newPath: string };
  };
  "file.delete": {
    params: { path: string };
    result: { ok: boolean };
  };
  "file.copy": {
    params: { srcPath: string; destDir: string };
    result: { path: string };
  };
  "file.readFile": {
    params: { path: string };
    result: { content: string; size: number };
  };
  "file.writeFile": {
    params: { path: string; content: string };
    result: { ok: boolean };
  };
  "file.editFile": {
    params: { path: string; edits: Array<{ oldText: string; newText: string }> };
    result: { ok: boolean };
  };
}
