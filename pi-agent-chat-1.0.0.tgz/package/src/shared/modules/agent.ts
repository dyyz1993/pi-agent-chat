import type { AgentEvent as UpstreamAgentEvent } from "@dyyz1993/pi-agent-core";
import type { TreeEntry } from "@dyyz1993/pi-coding-agent";
import type {
  AssistantMessage,
  AssistantMessageEvent,
  TextContent,
  Usage,
  StopReason,
  ToolCall,
  ThinkingContent,
} from "@dyyz1993/pi-ai";

export interface AgentMethods {
  "agent.start": {
    params: { sessionId: string; projectPath: string; sessionPath: string };
    result: { agentId: string; status: "started" | "already_running" | "switched" };
  };
  "agent.replayHoldEvents": {
    params: { sessionId: string };
    result: { replayed: number };
  };
  "agent.send": {
    params: { sessionId: string; content: string };
    result: { ok: boolean };
  };
  "agent.stop": {
    params: { sessionId: string };
    result: { ok: boolean };
  };
  "agent.getStatus": {
    params: { sessionId: string };
    result: { status: "idle" | "streaming" | "stopped"; pid?: number };
  };
  "agent.respondUI": {
    params: { sessionId: string; requestId: string; response: Record<string, unknown> };
    result: { ok: boolean };
  };
  "agent.getState": {
    params: { sessionId: string };
    result: {
      model?: {
        id: string;
        name?: string;
        api?: string;
        provider?: string;
        reasoning?: boolean;
        contextWindow: number;
        maxTokens: number;
      };
      thinkingLevel?: string;
      isStreaming: boolean;
      isCompacting: boolean;
      steeringMode?: string;
      followUpMode?: string;
      messageCount: number;
    } | null;
  };
  "agent.getCommands": {
    params: { sessionId: string };
    result: Array<{
      name: string;
      description: string;
      source: "extension" | "prompt" | "skill";
    }>;
  };
  "agent.getSessionStats": {
    params: { sessionId: string };
    result: {
      tokens: {
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
        total: number;
      };
      cost: number;
      contextUsage?: { tokens: number | null; contextWindow: number; percent: number | null };
    } | null;
  };
  "agent.getMessages": {
    params: { sessionId: string; sessionPath?: string };
    result: { messages: AgentMessageForUI[]; customEntries: CustomEntryForUI[] };
  };
  "agent.getFullMessages": {
    params: { sessionId: string; sessionPath?: string };
    result: { messages: AgentMessageForUI[]; customEntries: CustomEntryForUI[] };
  };
  "agent.steer": {
    params: { sessionId: string; content: string };
    result: { ok: boolean };
  };
  "agent.followUp": {
    params: { sessionId: string; content: string };
    result: { ok: boolean };
  };
  "agent.abort": {
    params: { sessionId: string };
    result: { ok: boolean };
  };
  "agent.setCwd": {
    params: { sessionId: string; cwd: string };
    result: { ok: boolean };
  };
  "agent.getAvailableModels": {
    params: { sessionId: string };
    result: Array<{ provider: string; id: string; contextWindow: number; reasoning: boolean }>;
  };
  "agent.setModel": {
    params: { sessionId: string; provider: string; modelId: string };
    result: { provider: string; id: string };
  };
  "agent.cycleModel": {
    params: { sessionId: string };
    result: {
      model: { provider: string; id: string };
      thinkingLevel: string;
      isScoped: boolean;
    } | null;
  };
  "agent.setThinkingLevel": {
    params: { sessionId: string; level: string };
    result: { ok: boolean };
  };
  "agent.cycleThinkingLevel": {
    params: { sessionId: string };
    result: { level: string } | null;
  };
  "agent.compact": {
    params: { sessionId: string; customInstructions?: string };
    result: { summary: string; tokensBefore: number };
  };
  "agent.setAutoCompaction": {
    params: { sessionId: string; enabled: boolean };
    result: { ok: boolean };
  };
  "agent.setAutoRetry": {
    params: { sessionId: string; enabled: boolean };
    result: { ok: boolean };
  };
  "agent.abortRetry": {
    params: { sessionId: string };
    result: { ok: boolean };
  };
  "agent.setSteeringMode": {
    params: { sessionId: string; mode: string };
    result: { ok: boolean };
  };
  "agent.setFollowUpMode": {
    params: { sessionId: string; mode: string };
    result: { ok: boolean };
  };
  "agent.getActiveTools": {
    params: { sessionId: string };
    result: { toolNames: string[] };
  };
  "agent.setActiveTools": {
    params: { sessionId: string; toolNames: string[] };
    result: { ok: boolean };
  };
  "agent.getQueue": {
    params: { sessionId: string };
    result: { steering: string[]; followUp: string[] };
  };
  "agent.clearQueue": {
    params: { sessionId: string };
    result: { steering: string[]; followUp: string[] };
  };
  "agent.getExtensions": {
    params: { sessionId: string };
    result: {
      extensions: Array<{
        path: string;
        resolvedPath: string;
        toolNames: string[];
        commandNames: string[];
      }>;
    };
  };
  "agent.getSkills": {
    params: { sessionId: string };
    result: {
      skills: Array<{
        name: string;
        description: string;
        filePath: string;
        baseDir: string;
        disableModelInvocation: boolean;
      }>;
    };
  };
  "agent.getDisabledSkills": {
    params: Record<string, never>;
    result: { disabledSkills: string[] };
  };
  "agent.setDisabledSkill": {
    params: { skillName: string; disabled: boolean };
    result: { disabledSkills: string[] };
  };
  "agent.getTools": {
    params: { sessionId: string };
    result: { tools: Array<{ name: string; label: string; description: string }> };
  };
  "agent.getMcpServers": {
    params: { sessionId: string };
    result: {
      servers: Array<{
        name: string;
        status: "connecting" | "connected" | "error" | "disconnected";
        error?: string;
        tools: Array<{
          originalName: string;
          fullName: string;
          description: string;
        }>;
        scope: "global" | "project";
        disabled?: boolean;
      }>;
    };
  };
  "agent.toggleMcpServer": {
    params: { sessionId: string; name: string; enabled: boolean };
    result: { success: boolean; error?: string };
  };
  "agent.restartMcpServer": {
    params: { sessionId: string; name: string };
    result: { success: boolean; error?: string };
  };
  "agent.reload": {
    params: { sessionId: string };
    result: void;
  };
  "agent.getContextUsage": {
    params: { sessionId: string };
    result: { tokens: number | null; contextWindow: number; percent: number | null };
  };
  "agent.getTierModels": {
    params: { sessionId: string };
    result: { models: Record<string, string> };
  };
  "agent.setTierModels": {
    params: { sessionId: string; models: Record<string, string> };
    result: { ok: boolean };
  };
  "agent.getSettings": {
    params: { sessionId: string; scope?: string };
    result: Record<string, unknown>;
  };
  "agent.setSettings": {
    params: { sessionId: string; settings: Record<string, unknown>; scope?: string };
    result: { ok: boolean };
  };
  "agent.setSessionName": {
    params: { sessionId: string; name: string };
    result: { ok: boolean };
  };
  "agent.getLastAssistantText": {
    params: { sessionId: string };
    result: { text: string | null };
  };
  "agent.getForkMessages": {
    params: { sessionId: string };
    result: { messages: Array<{ entryId: string; text: string }> };
  };
  "agent.fork": {
    params: { sessionId: string; entryId: string; position?: "before" | "at" };
    result: { text: string; cancelled: boolean; newSessionFile?: string; newSessionId?: string };
  };
  "agent.navigateTree": {
    params: { sessionId: string; targetId: string; summarize?: boolean; skipFiles?: boolean };
    result: { cancelled: boolean };
  };
  "agent.previewRollback": {
    params: { sessionId: string; targetId: string };
    result: { restored: string[]; deleted: string[] };
  };
  "agent.getModifiedFiles": {
    params: { sessionId: string; fromEntryId?: string; toEntryId?: string };
    result: Array<{
      path: string;
      status: "added" | "modified" | "deleted";
      turnIndex: number;
      entryId: string;
    }>;
  };
  "agent.getBatchDiffs": {
    params: { sessionId: string; fromEntryId?: string; toEntryId?: string };
    result: {
      files: Array<{
        path: string;
        status: "added" | "modified" | "deleted";
        diff: {
          path: string;
          oldContent: string | null;
          newContent: string | null;
          unifiedDiff: string;
        } | null;
      }>;
      summary: { totalFiles: number; added: number; modified: number; deleted: number };
    };
  };
  "agent.getTree": {
    params: { sessionId: string };
    result: { entries: TreeEntry[] };
  };
  "agent.clone": {
    params: { sessionId: string };
    result: { cancelled: boolean };
  };
  "agent.newSession": {
    params: { sessionId: string; parentSession?: string };
    result: { cancelled: boolean };
  };
  "agent.exportHtml": {
    params: { sessionId: string; outputPath?: string };
    result: { path: string };
  };
  "agent.getAgents": {
    params: { sessionId: string };
    result: {
      agents: Array<{
        name: string;
        description?: string;
        tier?: string;
        tools?: string[];
        permissionMode?: string;
        source: string;
        filePath: string;
      }>;
    };
  };
  "agent.switchAgent": {
    params: { sessionId: string; agentName: string };
    result: {
      agentName: string;
      tools: string[];
      tier?: string;
      thinkingLevel?: string;
    };
  };
  "agent.getCurrentAgent": {
    params: { sessionId: string };
    result: { agentName: string | null };
  };
}

export interface AgentMessageForUI {
  role: string;
  content: (TextContent | ThinkingContent | ToolCall)[];
  usage?: Usage;
  stopReason?: StopReason;
  provider?: string;
  model?: string;
  id?: string;
  timestamp?: string;
}

export interface CustomEntryForUI {
  id: string;
  customType: string;
  data: unknown;
  timestamp: number;
}

export interface AgentEvents {
  "agent.event": AgentEventPayload;
  "agent.notify": { sessionId: string; message: string; notifyType: "info" | "warning" | "error" };
  "agent.session_status_changed": { sessionId: string; projectPath: string; status: string };
}

export interface AgentEventPayload {
  sessionId: string;
  event: AgentEvent;
}

export interface ChannelDataEvent {
  type: "channel_data";
  name: string;
  data: Record<string, unknown>;
}

export interface ExtensionUIRequestEvent {
  type: "extension_ui_request";
  id: string;
  method:
    | "select"
    | "confirm"
    | "input"
    | "editor"
    | "notify"
    | "setStatus"
    | "setWidget"
    | "setTitle"
    | "set_editor_text";
  title?: string;
  message?: string;
  options?: string[];
  multiple?: boolean;
  placeholder?: string;
  prefill?: string;
  timeout?: number;
  notifyType?: "info" | "warning" | "error";
  statusKey?: string;
  statusText?: string;
  widgetKey?: string;
  widgetLines?: string[];
  widgetPlacement?: "aboveEditor" | "belowEditor";
  text?: string;
}

export interface CompactionResult {
  tokensAfter?: number;
  tokensBefore?: number;
}

export type AgentEvent =
  | UpstreamAgentEvent
  | { type: "compaction_start"; reason: string }
  | { type: "compaction_end"; reason: string; result: CompactionResult; aborted: boolean }
  | { type: "queue_update"; steering: string[]; followUp: string[] }
  | ExtensionUIRequestEvent
  | ChannelDataEvent
  | { type: "custom_entry"; customType: string; data: unknown; id: string; display?: boolean }
  | { type: "session_rename"; oldName: string | undefined; newName: string }
  | {
      type: "auto_retry_start";
      attempt: number;
      maxAttempts: number;
      delayMs: number;
      errorMessage: string;
    }
  | { type: "auto_retry_end"; success: boolean; attempt: number; finalError?: string }
  | {
      type: "mcp_connection_change";
      name: string;
      status: "connecting" | "connected" | "error" | "disconnected";
      error?: string;
      tools: Array<{ originalName: string; fullName: string; description: string }>;
    };

export type { AssistantMessage, AssistantMessageEvent, TextContent };

export type MessageData = AssistantMessage;

export interface AgentProcessInfo {
  sessionId: string;
  projectPath: string;
  sessionPath: string;
  status: "idle" | "streaming";
  holdEvents: AgentEvent[];
}
